
from re import T
from select import select
from tkinter import *
from tkcalendar import *
from PIL import ImageTk,Image
root=Tk()
root.geometry("1000x630")
root.title("Planner")

#bgframe=Image.open('images\\bg.png')
#photo=ImageTk.PhotoImage(bgframe)
#bg=Label(root,image=photo)
#bg.image=phot
#bg.pack(fill='both',expand='yes')
def setting():
    root2=Tk()
    root2.geometry("1000x630")
    root2.title("Setting")
    root2.mainloop()
def creatTask():
    root1=Tk()
    root1.geometry("450x635")
    root1.title("Create Task")
    #Frame
    inFrame1=Frame(root1,bg='#848482',width='450',height=635)
    inFrame1.place(x=0,y=0)
    #image
    inImg1=Image.open('images\\task.png')
    createTaskImg=inImg1.resize((42,42))
    photo=ImageTk.PhotoImage(createTaskImg)
  
    createTaskImageLabel=Label(inFrame1,image=photo,bg='#A9A9A9')
    createTaskImageLabel.image=photo
    createTaskImageLabel.pack(x=10,y=15)


    inLabel1=Label(inFrame1,text='Create Task',font=('yu gothic ui',25,'bold'),fg='black',bg='#848482')
    inLabel1.place(x=60,y=5)
   
    root1.mainloop()

frame1=Frame(root,bg='#686A6C',width='1000',height=50)
frame1.place(x=0,y=0)
#AddTaskImg
img1=Image.open('images\\add.png')
addTaskImg=img1.resize((43,43))
photo=ImageTk.PhotoImage(addTaskImg)
addImgButton=Button(frame1,image=photo,bg='#686A6C',command=creatTask,borderwidth=0)
addImgButton.image=photo
addImgButton.place(x=5,y=2)
#addImgLabel.bind('<Button-1>',creatTask)

#SettingImg
img2=Image.open('images\\setting.png')
settingImg=img2.resize((43,43))
photo=ImageTk.PhotoImage(settingImg)
settingImageButton=Button(frame1,image=photo,bg='#686A6C',command=setting,borderwidth=0)
settingImageButton.image=photo
settingImageButton.place(x=945,y=2)
#settingImageLabel.bind('<Button-1>',setting)
#calendar
frame2=Frame(root,bg='black',width='1000',height=100)
frame2.place(x=0,y=52)
cal = Calendar(frame2,font="Times 30",selectmode ='day',year=2022,month=1,day=1)
cal.pack(fill="both",expand=True)

frame3=Frame(root,bg='#A9A9A9',width='357',height=580)
frame3.place(x=643,y=52)
#taskImg
img3=Image.open('images\\todotask.png')
taskImg=img3.resize((42,42))
photo=ImageTk.PhotoImage(taskImg)
taskImageLabel=Label(frame3,image=photo,bg='#A9A9A9')
taskImageLabel.image=photo
taskImageLabel.place(x=10,y=15)
#taskLabel
label1=Label(frame3,text='Task to do',fg='black',bg='#A9A9A9',font=('yu gothic ui', 30 ,'bold'))
label1.place(x=60,y=5)

label2=Label(frame3,text='Nothing to do..',fg='black',bg='#A9A9A9',font=('yu gothic ui', 20 ,))
label2.place(x=30,y=100)


root.mainloop()
