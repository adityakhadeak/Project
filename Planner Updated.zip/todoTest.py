
from dataclasses import field
from re import T
from select import select
from tkinter import *
from tkinter import font
from tkinter.ttk import Style
from turtle import bgcolor, width
from tkcalendar import *
from PIL import ImageTk,Image
from tktimepicker import *

import sqlite3

conn=sqlite3.connect('PlannerDataBase.db')
c=conn.cursor()
#create a table
#c.execute("DROP TABLE IF EXISTS STUDENT")
#c.execute('''CREATE TABLE REGISTRATIONINFO(register_Name TEXT,
 #register_UserName TEXT,register_Gender TEXT, register_Password TEXT,register_DOB TEXT)''')
conn.commit()

root=Tk()
root.geometry("1280x720")
root.title("Planner")

#bgframe=Image.open('images\\bg.png')
#photo=ImageTk.PhotoImage(bgframe)
#bg=Label(root,image=photo)
#bg.image=phot
#bg.pack(fill='both',expand='yes')

def changeToSet():
    global mainFrame1
    mainFrame1.forget()
    settingWinMain.pack(fill=BOTH,expand=True)

def changeToMain():
    mainFrame1.pack(fill=BOTH,expand=True)
    loginFrame.forget()
    settingWinMain.forget()
    accSettingWinFrame.pack(fill=BOTH,expand=True)
    securitySettingWinFrame.forget()
def changeToRegistration():
    registerFrame.pack(fill=BOTH,expand=True)
    loginFrame.forget()
    
def changeToLogin():
    registerFrame.forget()
    settingWinMain.forget()
    accSettingWinFrame.forget()
    loginFrame.pack(fill=BOTH,expand=True)

def changeToSecuritySettingWin():
    securitySettingWinFrame.pack(fill=BOTH,expand=True)
    accSettingWinFrame.forget()

def changeToAccSetting():
    accSettingWinFrame.pack(fill=BOTH,expand=True)
    securitySettingWinFrame.forget()
    #settingAccWin.forget()
def creatTask():
    root1=Toplevel()
    root1.geometry("535x674")
    root1.title("Create Task")
    #Frame
    inFrame1=Frame(root1,bg='#313131',width='535',height=674)
    inFrame1.place(x=0,y=0)
    #image
    inImg1=Image.open('images\\createtask1.png')
   #createTaskImg=inImg1.resize((,674))
    photo=ImageTk.PhotoImage(inImg1)
    createTaskImageLabel=Label(inFrame1,image=photo,bg='#313131')
    createTaskImageLabel.image=photo
    createTaskImageLabel.place(x=0,y=0)
    #inLabel1=Label(inFrame1,text='Create Task',font=('yu gothic ui',25,'bold'),bg='#313131')
    #inLabel1.place(x=60,y=5)
    inEntry1=Entry(inFrame1,width='30',font=('Times',20),bg='#313131',borderwidth=0,fg='white',insertbackground='white')
    inEntry1.place(x=21,y=117)

    inText1=Text(inFrame1,width='35',height=5,font=('Times',20),fg='white',insertbackground='white',bg='#313131',borderwidth=0)
    inText1.place(x=20,y=192)
    #Datepicker
    datePicker=DateEntry(inFrame1,width=10,font=('Times',15),fg='white')
    datePicker.place(x=25,y=400)
    #TimePicker
    timePicker=SpinTimePickerModern(inFrame1)
    timePicker.addAll(constants.HOURS24)
    timePicker.configureAll(bg="#313131", height=1,width=2, fg="white", font=("Times", 16),hoverbg="#313131",
                            hovercolor="#313131", clickedbg="#313131", clickedcolor="white")
    timePicker.configure_separator(bg="#313131", fg="#ffffff")
    timePicker.place(x=245,y=400)
    #Setpriority
    taskMenu= StringVar()
    taskMenu.set("Set Priority")
    setPriority= OptionMenu(inFrame1, taskMenu,"Low", "Medium","High")
    setPriority.config(bg="#313131", fg="WHITE",font=('Times',15), highlightbackground="#313131")
    setPriority["menu"].config(bg="#313131",fg='white')
    setPriority.place(x=25,y=472)

    #Submit Button
    img4=Image.open('images\\submitButton.png')
    #subImg=img4.resize((43,43))
    photo=ImageTk.PhotoImage(img4)
    subImageButton=Button(inFrame1,image=photo,bg='#313131',borderwidth=0, activebackground='#313131')
    subImageButton.image=photo
    subImageButton.place(x=415,y=598)

    #Cancel Button
    img5=Image.open('images\\cancelButton.png')
    #cancelImg=img4.resize((43,43))
    photo=ImageTk.PhotoImage(img5)
    cancelImageButton=Button(inFrame1,image=photo,bg='#313131',command=root1.destroy,borderwidth=0, activebackground='#313131')
    cancelImageButton.image=photo
    cancelImageButton.place(x=294,y=598)
    root1.mainloop()


#loginFrame
loginFrame=Frame(root)
loginFrame.pack(fill=BOTH,expand=True)
# Giving Dimensions and background image
loginImg = PhotoImage(file='images//loginWin.png', master=loginFrame)
loginImg_label = Label(loginFrame, image=loginImg)
loginImg_label.place(x=0, y=0)
# Placing Submit Button
loginSubmitButtonImg = PhotoImage(file="images//loginSubmitButton.png",master=loginFrame)
loginSubmitButton = Button(loginFrame,image=loginSubmitButtonImg, border=0,
                background="#d1d1d1", activebackground="#d1d1d1",command=changeToMain)
loginSubmitButton.place(x=1114, y=449)
# Placing forgotPassword Button
forgotPasswordButton = PhotoImage(file="images//forgotPasswordButton.png",master=loginFrame)
forgotPassword = Button(loginFrame,image=forgotPasswordButton, border=0,
                        background="#d1d1d1", activebackground="#d1d1d1")
forgotPassword.place(x=1111, y=508)
# Placing register Button
registerButton = PhotoImage(file="images//registerButton.png")
register = Button(loginFrame,image=registerButton, border=0,
                  background="#d1d1d1", activebackground="#d1d1d1",command=changeToRegistration)
register.place(x=821, y=671)
# Placing Text Entry of Username
loginUserName = Entry(loginFrame,background="#d1d1d1", border=0, width=40, font=("Inter", 15))
loginUserName.place(x=764, y=290, height=43)
# Placing Text Entry of Password
loginPassword = Entry(loginFrame,background="#d1d1d1", border=0,
                 width=40, show="*", font=("Inter", 15))
loginPassword.place(x=764, y=363, height=43)




#registrationWindow Frame
registerFrame=Frame(root)
#registerFrame.pack(fill=BOTH,expand=True)
#registrationImage
registrationWinImg=Image.open('images\\registrationWin.png')
photo=ImageTk.PhotoImage(registrationWinImg)
registrationWinLabel=Label(registerFrame,image=photo,bg='#313131')
registrationWinLabel.image=photo
registrationWinLabel.place(x=0,y=0)

#registrationName
registerNameEntry=Entry(registerFrame,width='31',bg='#D1D1D1',fg='#313131',borderwidth=0,insertbackground='black',font=("Inter", 18))
registerNameEntry.place(x=100,y=162)
#registrationUserName
registerUserNameEntry=Entry(registerFrame,width='31',bg='#D1D1D1',fg='#313131',borderwidth=0,insertbackground='black',font=("Inter", 18))
registerUserNameEntry.place(x=100,y=235)
#SetGender
registerGenderMenu= StringVar()
registerGenderMenu.set("Select Gender")
setRegisterGender= OptionMenu(registerFrame,registerGenderMenu,"Male", "Female","Other")
setRegisterGender.config(bg="#D1D1D1",border=0, fg="#313131",font=('Times',15),highlightthickness=0)
setRegisterGender["menu"].config(bg="#D1D1D1",fg='#313131')
setRegisterGender.place(x=100,y=306)
#registrationPassword
registerPasswordEntry=Entry(registerFrame,width='31',bg='#D1D1D1',fg='#313131',show='*',borderwidth=0,insertbackground='black',font=("Inter", 18))
registerPasswordEntry.place(x=100,y=381)
#registrationRePassword
registerRePasswordEntry=Entry(registerFrame,width='31',bg='#D1D1D1',fg='#313131',show='*',borderwidth=0,insertbackground='black',font=("Inter", 18))
registerRePasswordEntry.place(x=100,y=454)
#registerDOBpicker
registerDatePicker=DateEntry(registerFrame,width=10,font=('Times',15),fg='white')
registerDatePicker.place(x=100,y=527)
#registrationSubmitButton
registrationSubmitButtonImg=Image.open('images\\registerSubmitButton.png')
photo=ImageTk.PhotoImage(registrationSubmitButtonImg)
registrationSubmitButton=Button(registerFrame,image=photo,bg='#D1D1D1',borderwidth=0, activebackground='#D1D1D1',command=changeToLogin)
registrationSubmitButton.image=photo
registrationSubmitButton.place(x=444,y=612)


#ShowTaskWindow
mainFrame1=Frame(root)
#mainFrame1.pack(fill=BOTH,expand=True)

#ShowTaskWindowImg
mainImg1=Image.open('images\\planner.png')
photo=ImageTk.PhotoImage(mainImg1)
mainImg1Label=Label(mainFrame1,image=photo,bg='#313131')
mainImg1Label.image=photo
mainImg1Label.place(x=0,y=0)
#AddTaskImg
img1=Image.open('images\\add.png')
addTaskImg=img1.resize((48,48))
photo=ImageTk.PhotoImage(addTaskImg)
addImgButton=Button(mainFrame1,image=photo,bg='#313131',command=creatTask,borderwidth=0,activebackground='#313131')
addImgButton.image=photo
addImgButton.place(x=12,y=15)
#SettingImg
img2=Image.open('images\\settingsButton.png')
photo=ImageTk.PhotoImage(img2)
settingImageButton=Button(mainFrame1,image=photo,bg='#313131',command=changeToSet,borderwidth=0,activebackground='#313131')
settingImageButton.image=photo
settingImageButton.place(x=1205,y=1)
#calendar
frame2=Frame(mainFrame1,bg='#313131',width='864',height=645)
frame2.place(x=2,y=80)
cal = Calendar(frame2,font="Times 35",selectmode ='day',year=2022,month=1,day=1,bgcolor='#313131')
cal.pack(fill="both",expand=True)
#taskImg
img3=Image.open('images\\todotask.png')
taskImg=img3.resize((32,32))
photo=ImageTk.PhotoImage(taskImg)
taskImageLabel=Label(mainFrame1,image=photo,bg='#313131')
taskImageLabel.image=photo
taskImageLabel.place(x=880,y=90)
#taskLabel
label1=Label(mainFrame1,text='Task to do',fg='white',bg='#313131',font=('Sans-serif', 27 ))
label1.place(x=930,y=85)
label2=Label(mainFrame1,text='Nothing to do..',fg='white',bg='#313131',font=('yu gothic ui', 20 ,))
label2.place(x=950,y=150)


#SettingWinMainFrame
settingWinMain=Frame(root,bg='#313131',width='1280',height=720)
#SettingWinImg
settingWinMainImg=Image.open('images\\settingWinMain.png')
photo=ImageTk.PhotoImage(settingWinMainImg)
settingWinMainImageLabel=Label(settingWinMain,image=photo,bg='#313131')
settingWinMainImageLabel.image=photo
settingWinMainImageLabel.place(x=0,y=0)







#accSettingWinFrame
accSettingWinFrame=Frame(settingWinMain)
accSettingWinFrame.pack(fill=BOTH,expand=True)
accSettingWinImg=Image.open('images\\accSettingWin.png')
photo=ImageTk.PhotoImage(accSettingWinImg)
accSettingWinLabel=Label(accSettingWinFrame,image=photo,bg='#313131')
accSettingWinLabel.image=photo
accSettingWinLabel.place(x=0,y=0)

#accountsettingButton
accSettingImg=Image.open('images\\accountSettingsButton.png')
photo=ImageTk.PhotoImage(accSettingImg)
accsetImageButton=Button(accSettingWinFrame,image=photo,bg='#313131',borderwidth=0, 
                         activebackground='#313131',command=changeToAccSetting)
accsetImageButton.image=photo
accsetImageButton.place(x=0,y=177)
#securitySettingsButton
securitySettingImg=Image.open('images\\securitySettingsButton.png')
photo=ImageTk.PhotoImage(securitySettingImg)
secsetImageButton=Button(accSettingWinFrame,image=photo,bg='#313131',borderwidth=0, 
                        activebackground='#313131',command=changeToSecuritySettingWin)
secsetImageButton.image=photo
secsetImageButton.place(x=0,y=236)
#BackButton
settingBackButtonImg=Image.open('images\\backButton.png')
photo=ImageTk.PhotoImage(settingBackButtonImg)
settingBackButton=Button(accSettingWinFrame,image=photo,bg='#313131',borderwidth=0, command=changeToMain,activebackground='#313131')
settingBackButton.image=photo
settingBackButton.place(x=0,y=-1)

#nameButton
img7=Image.open('images\\nameButton.png')
photo=ImageTk.PhotoImage(img7)
namesetImageButton=Button(accSettingWinFrame,image=photo,bg='#313131',borderwidth=0, activebackground='#313131')
namesetImageButton.image=photo
namesetImageButton.place(x=394,y=421)
#SignOutButton
signOutButtonImg=Image.open('images\\signOutButton.png')
photo=ImageTk.PhotoImage(signOutButtonImg)
signOutButton=Button(accSettingWinFrame,image=photo,bg='#313131',borderwidth=0, command=changeToLogin,activebackground='#313131')
signOutButton.image=photo
signOutButton.place(x=394,y=648)



#securitySettingWinFrame
securitySettingWinFrame=Frame(settingWinMain)
securitySettingWinImg=Image.open('images\\securitySettingWin.png')
photo=ImageTk.PhotoImage(securitySettingWinImg)
securitySettingWinLabel=Label(securitySettingWinFrame,image=photo,bg='#313131')
securitySettingWinLabel.image=photo
securitySettingWinLabel.place(x=0,y=0)

#accountsettingButton
accSettingImg=Image.open('images\\accountSettingsButton.png')
photo=ImageTk.PhotoImage(accSettingImg)
accsetImageButton=Button(securitySettingWinFrame,image=photo,bg='#313131',borderwidth=0, 
                         activebackground='#313131',command=changeToAccSetting)
accsetImageButton.image=photo
accsetImageButton.place(x=0,y=177)
#securitySettingsButton
securitySettingImg=Image.open('images\\securitySettingsButton.png')
photo=ImageTk.PhotoImage(securitySettingImg)
secsetImageButton=Button(securitySettingWinFrame,image=photo,bg='#313131',borderwidth=0, 
                        activebackground='#313131',command=changeToSecuritySettingWin)
secsetImageButton.image=photo
secsetImageButton.place(x=0,y=236)
#BackButton
settingBackButtonImg=Image.open('images\\backButton.png')
photo=ImageTk.PhotoImage(settingBackButtonImg)
settingBackButton=Button(securitySettingWinFrame,image=photo,bg='#313131',borderwidth=0, command=changeToMain,activebackground='#313131')
settingBackButton.image=photo
settingBackButton.place(x=0,y=-1)






root.mainloop()
